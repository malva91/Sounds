
/**
 * Soundboard Room Sync (Firebase RTDB)
 * - Adds "room" controls UI (connect/disconnect)
 * - Syncs play/pause/seek/loop and current track across clients in the same room
 * - Provides a per-room tag mixer (0..1) that multiplies local volumes
 *
 * Credentials: fill firebaseConfig below.
 * This module is self-contained and aims to be non-invasive:
 *   - It observes <audio> elements to detect playback actions.
 *   - It scans the DOM for elements with [data-tags] and [data-filename] to infer tags per track.
 *   - If your markup differs, the sync still works for transport (play/pause/seek/loop) using src filename.
 */

const firebaseConfig = {
  apiKey: "AIzaSyBFO4AAdUIg824yKqZVxvEhjBQ_BjAcRh4",
  authDomain: "nomicosecitta-115eb.firebaseapp.com",
  databaseURL: "https://nomicosecitta-115eb-default-rtdb.europe-west1.firebasedatabase.app",
  projectId: "nomicosecitta-115eb",
  storageBucket: "nomicosecitta-115eb.firebasestorage.app",
  messagingSenderId: "327579378248",
  appId: "1:327579378248:web:39378162723aa7ef316e7d",
  measurementId: "G-L4CT6VN2DJ"
};

let FB = null;
async function initFirebase() {
  if (FB) return FB;
  const { initializeApp } = await import("https://www.gstatic.com/firebasejs/10.12.2/firebase-app.js");
  const {
    getDatabase, ref, onValue, set, update, serverTimestamp, onDisconnect, remove
  } = await import("https://www.gstatic.com/firebasejs/10.12.2/firebase-database.js");

  const app = initializeApp(firebaseConfig);
  const db  = getDatabase(app);
  FB = { app, db, ref, onValue, set, update, serverTimestamp, onDisconnect, remove };
  return FB;
}

/* ---------------- UI injection ---------------- */
function injectStyles(css) {
  const s = document.createElement("style");
  s.textContent = css;
  document.head.appendChild(s);
}
injectStyles(`
  .room-sync { display:flex; gap:.5rem; align-items:center; flex-wrap: wrap; margin:.5rem 0; }
  .room-sync input { min-width: 14rem; padding:.35rem .5rem; }
  .room-sync button { padding:.35rem .6rem; border-radius:.5rem; border:1px solid #ccc; background:#f7f7f7; cursor:pointer; }
  .room-sync button:hover { background:#eee; }
  .room-status { font-size:.9rem; opacity:.85; }
  .room-mixer summary { cursor:pointer; }
  .room-mixer { margin:.25rem 0 1rem; }
  .tag-sliders { display:grid; grid-template-columns: 1fr auto; gap:.5rem 1rem; padding-top:.5rem; }
  .tag-sliders label { align-self:center; }
`);

function ensureToolbarContainer() {
  // Try to place in an existing toolbar. Fallback: top of body.
  const toolbar = document.querySelector(".toolbar, header, .topbar, .controls") || document.body;
  // Prevent duplicate
  if (document.getElementById("room-sync-root")) return;

  const wrap = document.createElement("div");
  wrap.id = "room-sync-root";
  wrap.innerHTML = `
    <div class="room-sync">
      <input id="room-name" type="text" placeholder="Nome stanza (stesso per tutti)" aria-label="Nome stanza"/>
      <button id="room-connect-btn" type="button">Connetti</button>
      <span id="room-status" class="room-status" aria-live="polite">Offline</span>
    </div>
    <details id="room-mixer" class="room-mixer" style="display:none;">
      <summary>🎚️ Volumi tag (stanza)</summary>
      <div id="room-tag-sliders" class="tag-sliders"></div>
    </details>
  `;
  toolbar.prepend(wrap);
}
ensureToolbarContainer();

/* ---------------- State ---------------- */
const syncState = {
  enabled: false,
  roomId: null,
  clientId: `${Math.random().toString(36).slice(2)}-${Date.now()}`,
  lastPushAt: 0,
  driftThresholdMs: 180,
  unsubRoom: null,
  loopPrev: undefined,
};

let currentAudio = null;
let currentFilename = null;
let currentLabel = null;

const VolumeApplier = (() => {
  const applied = new WeakMap(); // audio -> lastMultiplier
  function set(audio, multiplier) {
    const last = applied.get(audio) ?? 1;
    // Avoid division by zero and clamp
    const base = audio.volume / (last || 1);
    const newVol = Math.max(0, Math.min(1, base * multiplier));
    audio.volume = newVol;
    applied.set(audio, multiplier || 1);
  }
  return { set };
})();

/* ------------- Tag discovery ------------- */
function collectAllTags() {
  const set = new Set();
  document.querySelectorAll("[data-tags]").forEach(el => {
    const t = (el.getAttribute("data-tags") || "").split(",").map(s => s.trim()).filter(Boolean);
    t.forEach(tag => set.add(tag));
  });
  return Array.from(set).sort((a,b)=>a.localeCompare(b));
}

function tagsForFilename(fname) {
  // Try to find any element matching this filename
  const selector = `[data-filename="${cssEscape(fname)}"], [data-file="${cssEscape(fname)}"], [data-src*="${cssEscape(fname)}"]`;
  const el = document.querySelector(selector);
  if (!el) return [];
  const raw = el.getAttribute("data-tags") || "";
  return raw.split(",").map(s => s.trim()).filter(Boolean);
}

function cssEscape(str) { return str.replace(/(["\\])/g, "\\$1"); }

/* ------------- Room tag volumes ------------- */
let roomTagVolumes = {}; // { tag: 0..1 }
function setRoomTagVolumes(map) { roomTagVolumes = map || {}; }
function getRoomTagVolume(tag) {
  const v = roomTagVolumes[tag];
  return (typeof v === "number") ? v : 1;
}
function roomMultiplierForFilename(fname) {
  const tags = tagsForFilename(fname);
  if (!tags.length) return 1;
  return tags.reduce((acc, t) => acc * getRoomTagVolume(t), 1);
}

function renderRoomTagMixer(map) {
  const container = document.getElementById("room-tag-sliders");
  if (!container) return;
  const tags = collectAllTags();
  container.innerHTML = "";
  tags.forEach(tag => {
    const v = (map && typeof map[tag] === "number") ? map[tag] : 1;
    const id = `room-tag-${tag}`;
    const label = document.createElement("label");
    label.setAttribute("for", id);
    label.textContent = `#${tag}`;

    const input = document.createElement("input");
    input.type = "range"; input.min = "0"; input.max = "1"; input.step = "0.01";
    input.id = id; input.value = String(v);

    input.addEventListener("input", throttle(async () => {
      if (!syncState.enabled) return;
      const FBp = await initFirebase();
      const { db, ref, update } = FBp;
      const value = parseFloat(input.value);
      await update(ref(db, `rooms/${syncState.roomId}/tagVolumes`), { [tag]: value });
    }, 150));

    container.appendChild(label);
    container.appendChild(input);
  });
}

function refreshPlayingVolumes() {
  if (!currentAudio || !currentFilename) return;
  const mult = roomMultiplierForFilename(currentFilename);
  VolumeApplier.set(currentAudio, mult);
}

/* ------------- Room UI wiring ------------- */
function setupRoomUI() {
  const roomInput = document.getElementById("room-name");
  const connectBtn = document.getElementById("room-connect-btn");
  const statusEl = document.getElementById("room-status");

  connectBtn?.addEventListener("click", async () => {
    const name = (roomInput?.value || "").trim();
    if (!name) return alert("Inserisci il nome della stanza (stesso per tutti).");
    if (syncState.enabled && syncState.roomId === name) {
      await leaveRoom();
      statusEl.textContent = "Disconnesso";
      connectBtn.textContent = "Connetti";
      return;
    }
    await joinRoom(name);
    statusEl.textContent = `Connesso: ${name}`;
    connectBtn.textContent = "Disconnetti";
  });

  window.addEventListener("online", () => statusEl.textContent = syncState.enabled ? `Connesso: ${syncState.roomId}` : "Online");
  window.addEventListener("offline", () => statusEl.textContent = "Offline");

  updateRoomMixerVisibility();
}
function updateRoomMixerVisibility() {
  const det = document.getElementById("room-mixer");
  if (det) det.style.display = syncState.enabled ? "" : "none";
}

/* ------------- Firebase room join/leave ------------- */
async function joinRoom(roomId) {
  const FBp = await initFirebase();
  const { db, ref, onValue, set, update, serverTimestamp, onDisconnect, remove } = FBp;

  syncState.roomId = roomId;
  syncState.enabled = true;

  const memberRef = ref(db, `rooms/${roomId}/members/${syncState.clientId}`);
  await set(memberRef, true);
  onDisconnect(memberRef).remove();

  // Room state listener
  const stateRef = ref(db, `rooms/${roomId}/state`);
  if (syncState.unsubRoom) syncState.unsubRoom();
  syncState.unsubRoom = onValue(stateRef, (snap) => {
    const remote = snap.val();
    if (!remote) return;
    if (remote.updatedBy === syncState.clientId) return;
    applyRemoteState(remote);
  });

  // Tag volume listener
  const tagVolRef = ref(db, `rooms/${roomId}/tagVolumes`);
  onValue(tagVolRef, (snap) => {
    const map = snap.val() || {};
    setRoomTagVolumes(map);
    renderRoomTagMixer(map);
    refreshPlayingVolumes();
  });

  updateRoomMixerVisibility();
}

async function leaveRoom() {
  if (!syncState.enabled) return;
  const FBp = await initFirebase();
  const { db, ref, remove } = FBp;
  try { await remove(ref(db, `rooms/${syncState.roomId}/members/${syncState.clientId}`)); } catch {}
  if (syncState.unsubRoom) { syncState.unsubRoom(); syncState.unsubRoom = null; }
  syncState.enabled = false;
  syncState.roomId = null;
  updateRoomMixerVisibility();
}

/* ------------- Publishing local state ------------- */
function nowMs(){ return Date.now(); }
const pushRoomStateThrottled = throttle(() => pushRoomState("timeupdate"), 1000);

async function pushRoomState(kind = "timeupdate") {
  if (!syncState.enabled || !currentAudio) return;
  const FBp = await initFirebase();
  const { db, ref, update, serverTimestamp } = FBp;

  const positionMs = Math.floor((currentAudio.currentTime || 0) * 1000);
  const payload = {
    filename: currentFilename || null,
    label: currentLabel || null,
    loop: !!currentAudio.loop,
    paused: currentAudio.paused,
    positionMs,
    startedAt: currentAudio.paused ? null : serverTimestamp(),
    updatedBy: syncState.clientId,
    kind,
  };
  await update(ref(db, `rooms/${syncState.roomId}/state`), payload);
  syncState.lastPushAt = nowMs();
}

/* ------------- Applying remote state ------------- */
function applyRemoteState(remote) {
  // Change track if needed
  if (remote.filename && remote.filename !== currentFilename) {
    loadAndPlayByFilename(remote.filename).then(() => {
      applyRemoteTransport(remote);
    });
    return;
  }
  applyRemoteTransport(remote);
}

function applyRemoteTransport(remote) {
  if (!currentAudio) return;

  // Loop
  currentAudio.loop = !!remote.loop;

  // Position (smooth correction if drift > threshold)
  const targetPos = computeTargetPosition(remote);
  if (typeof targetPos === "number") {
    const delta = Math.abs((currentAudio.currentTime || 0) - targetPos / 1000) * 1000;
    if (delta > syncState.driftThresholdMs) {
      try { currentAudio.currentTime = targetPos / 1000; } catch {}
    }
  }

  // Play/Pause
  if (remote.paused && !currentAudio.paused) currentAudio.pause();
  if (!remote.paused && currentAudio.paused) currentAudio.play();
}

function computeTargetPosition(remote) {
  if (remote.paused) return remote.positionMs ?? 0;
  if (remote.startedAt == null) return remote.positionMs ?? 0;
  const now = nowMs();
  const started = (typeof remote.startedAt === "number") ? remote.startedAt : now;
  const elapsed = Math.max(0, now - started);
  return (remote.positionMs ?? 0) + elapsed;
}

/* ------------- Hooks into <audio> globally ------------- */
function filenameFromSrc(src) {
  try {
    const u = new URL(src, location.href);
    const p = u.pathname;
    const name = p.substring(p.lastIndexOf("/") + 1);
    return decodeURIComponent(name);
  } catch { return src; }
}

function findAnyAudio() {
  return document.querySelector("audio");
}

function loadAndPlayByFilename(fname) {
  return new Promise((resolve) => {
    // Strategy: look for an existing pad/button with data-filename and click it.
    const btn = document.querySelector(`[data-filename="${cssEscape(fname)}"]`)
            || document.querySelector(`[data-file="${cssEscape(fname)}"]`);
    if (btn) {
      btn.click();
      setTimeout(resolve, 50);
      return;
    }
    // Fallback: if there's an <audio> with a matching src, use it
    const audios = Array.from(document.querySelectorAll("audio"));
    const target = audios.find(a => filenameFromSrc(a.currentSrc || a.src || "") === fname);
    if (target) {
      currentAudio = target;
      currentFilename = fname;
      target.play?.();
      setTimeout(resolve, 50);
      return;
    }
    // Last resort: create a hidden audio and play
    const audio = document.createElement("audio");
    audio.src = "sounds/" + fname; // common path; adjust if needed
    audio.preload = "auto";
    audio.addEventListener("loadedmetadata", () => {
      audio.play().catch(()=>{});
      resolve();
    }, { once: true });
    audio.style.display = "none";
    document.body.appendChild(audio);
    currentAudio = audio;
    currentFilename = fname;
  });
}

function attachGlobalAudioObservers() {
  document.addEventListener("play", (e) => {
    const a = e.target;
    if (!(a instanceof HTMLMediaElement)) return;
    currentAudio = a;
    currentFilename = filenameFromSrc(a.currentSrc || a.src || "");
    currentLabel = a.getAttribute("data-label") || currentFilename;
    refreshPlayingVolumes();
    if (syncState.enabled) pushRoomState("play");
  }, true);

  document.addEventListener("pause", (e) => {
    const a = e.target;
    if (!(a instanceof HTMLMediaElement)) return;
    if (a === currentAudio && syncState.enabled) pushRoomState("pause");
  }, true);

  document.addEventListener("seeked", (e) => {
    const a = e.target;
    if (!(a instanceof HTMLMediaElement)) return;
    if (a === currentAudio && syncState.enabled) pushRoomState("seek");
  }, true);

  document.addEventListener("timeupdate", (e) => {
    const a = e.target;
    if (!(a instanceof HTMLMediaElement)) return;
    if (a === currentAudio) {
      refreshPlayingVolumes();
      if (syncState.enabled) pushRoomStateThrottled();
    }
  }, true);

  // Loop change detection via polling
  setInterval(() => {
    if (!currentAudio) return;
    const loopNow = !!currentAudio.loop;
    if (loopNow !== syncState.loopPrev) {
      syncState.loopPrev = loopNow;
      if (syncState.enabled) pushRoomState("loop");
    }
  }, 300);
}

/* ------------- Utilities ------------- */
function throttle(fn, ms) {
  let last = 0, tid = null;
  return (...args) => {
    const t = Date.now();
    const invoke = () => { last = Date.now(); tid = null; fn(...args); };
    if (t - last >= ms) return invoke();
    if (!tid) tid = setTimeout(invoke, ms - (t - last));
  };
}

/* ------------- Init ------------- */
function initSyncModule() {
  setupRoomUI();
  renderRoomTagMixer({});
  attachGlobalAudioObservers();
}
document.addEventListener("DOMContentLoaded", initSyncModule);
